import { LightningElement, track } from 'lwc';

export default class HomeScreen extends LightningElement {
    @track showWelcome = true;
    @track showSignupForm = false;

    handleSignUp() {
        this.showWelcome = false;
        this.showSignupForm = true;
    }

    handleFormCancel() {
        // Voltar para a tela de boas-vindas
        this.showSignupForm = false;
        this.showWelcome = true;
    }
}