// signupForm.js
import { LightningElement, track } from 'lwc';
import processApplication from "@salesforce/apex/ApplicationFormController.processApplication";

export default class FormCompanyScreen extends LightningElement {
    @track formData = {
        companyName: '',
        email: '',
        phone: '',
        firstName: '',
        lastName: '',
        federalTaxId: '',
        annualRevenue: ''
    };

    // Modal properties
    @track showModal = false;
    @track isLoading = false;
    @track showSuccess = false;
    @track showError = false;
    @track modalTitle = '';
    @track modalMessage = '';

    handleInputChange(event) {
        const field = event.target.name;
        const value = event.target.value;
        this.formData = { ...this.formData, [field]: value };
    }

    handleSubmit() {
        if (this.validateForm()) {
            console.log('Form Data:', JSON.stringify(this.formData, null, 2));
            
            // Abrir modal com spinner
            this.openModal();
            this.saveData();
        }
    }

    validateForm() {
        const allValid = [...this.template.querySelectorAll('lightning-input')]
            .reduce((validSoFar, inputCmp) => {
                inputCmp.reportValidity();
                return validSoFar && inputCmp.checkValidity();
            }, true);

        if (!allValid) {
            return false;
        }

        return true;
    }

    saveData() {
        const dataToSend = {
            ...this.formData,
            annualRevenue: this.formData.annualRevenue ? 
                           parseFloat(this.formData.annualRevenue) : null
        };

        // Simular delay de 3 segundos + chamada Apex
        Promise.all([
            processApplication({ formData: dataToSend }),
            new Promise(resolve => setTimeout(resolve, 3000))
        ])
            .then(([result]) => {
                console.log('✅ Success!:', result);
                
                // Mostrar mensagem de sucesso
                this.showSuccessMessage(
                    'Success!',
                    result
                );
 
            })
            .catch(error => {
                console.error('Error:', error.body.pageErrors);
                
                let errorMessage = error.body?.message || 
                                    error.message || 
                                    error.body.pageErrors[0].statusCode ||
                                    'An error occurred while saving.';

                if(errorMessage.includes('DUPLICATE_VALUE')){
                    errorMessage = 'An account with this federalTaxId has already been registered.';
                } 
                
                // Mostrar mensagem de erro
                this.showErrorMessage(
                    'Error',
                    errorMessage
                );
            });
    }

    openModal() {
        this.showModal = true;
        this.isLoading = true;
        this.showSuccess = false;
        this.showError = false;
    }

    showSuccessMessage(title, message) {
        this.isLoading = false;
        this.showSuccess = true;
        this.showError = false;
        this.modalTitle = title;
        this.modalMessage = message;
    }

    showErrorMessage(title, message) {
        this.isLoading = false;
        this.showSuccess = false;
        this.showError = true;
        this.modalTitle = title;
        this.modalMessage = message;
    }

    closeModal() {
        this.showModal = false;
        this.isLoading = false;
        this.showSuccess = false;
        this.showError = false;
        this.modalTitle = '';
        this.modalMessage = '';
        this.handleCancel();
    }

    handleCancel() {
        this.resetForm();
        this.dispatchEvent(new CustomEvent('formcancel'));
    }

    resetForm() {
        this.formData = {
            companyName: '',
            email: '',
            phone: '',
            firstName: '',
            lastName: '',
            federalTaxId: '',
            annualRevenue: ''
        };

        const inputFields = this.template.querySelectorAll('lightning-input');
        if (inputFields) {
            inputFields.forEach(field => {
                field.value = '';
            });
        }
    }
}